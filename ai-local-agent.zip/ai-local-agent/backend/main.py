from fastapi import FastAPI
from pydantic import BaseModel
from agents.slogan_agent import generate_slogan
from agents.script_agent import generate_video_script
from agents.review_agent import analyze_reviews
from agents.campaign_agent import generate_campaign

app = FastAPI()

class BusinessInput(BaseModel):
    business_type: str
    business_name: str
    target_users: str
    city: str

class ReviewInput(BaseModel):
    reviews: list[str]

@app.get("/")
def root():
    return {"message": "AI Local Business Agent Running"}

@app.post("/generate-slogan")
def slogan(data: BusinessInput):
    return {
        "result": generate_slogan(
            data.business_type,
            data.business_name,
            data.target_users,
            data.city
        )
    }

@app.post("/generate-script")
def script(data: BusinessInput):
    return {
        "result": generate_video_script(
            data.business_type,
            data.business_name,
            data.target_users
        )
    }

@app.post("/analyze-reviews")
def reviews(data: ReviewInput):
    return {
        "result": analyze_reviews(data.reviews)
    }

@app.post("/generate-campaign")
def campaign(data: BusinessInput):
    return {
        "result": generate_campaign(
            data.business_type,
            data.business_name,
            data.target_users
        )
    }