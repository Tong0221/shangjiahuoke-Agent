from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_video_script(business_type, business_name, target_users):
    prompt = f'''
请生成适合抖音的短视频脚本。

商家：{business_name}
行业：{business_type}
用户：{target_users}

要求：
- 前3秒强钩子
- 有情绪冲突
- 有镜头脚本
- 有字幕文案
'''

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content