from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_campaign(business_type, business_name, target_users):
    prompt = f'''
请为以下本地商家生成营销活动方案：

商家：{business_name}
行业：{business_type}
用户：{target_users}

输出：
1. 活动主题
2. 引流玩法
3. 裂变方案
4. 短视频方案
'''

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content