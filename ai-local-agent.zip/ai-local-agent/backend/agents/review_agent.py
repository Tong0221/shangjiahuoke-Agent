from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def analyze_reviews(reviews):
    review_text = "\n".join(reviews)

    prompt = f'''
分析以下用户评论：

输出：
1. 用户最满意点
2. 用户最不满意点
3. 用户真实需求
4. 营销建议

评论：
{review_text}
'''

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content