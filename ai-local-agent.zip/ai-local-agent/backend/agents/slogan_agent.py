from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_slogan(business_type, business_name, target_users, city):
    prompt = f'''
你是一名顶级本地商业营销策划师。

请为以下商家生成：
1. 洗脑广告语
2. 门头文案
3. 抖音风格宣传语

商家名称：{business_name}
行业：{business_type}
用户：{target_users}
城市：{city}
'''

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content