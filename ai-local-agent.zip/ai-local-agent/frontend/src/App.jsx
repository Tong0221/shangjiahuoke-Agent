import { useState } from 'react'
import api from './api'

export default function App() {
  const [businessName, setBusinessName] = useState('')
  const [businessType, setBusinessType] = useState('')
  const [targetUsers, setTargetUsers] = useState('')
  const [city, setCity] = useState('')
  const [result, setResult] = useState('')

  const generate = async () => {
    const res = await api.post('/generate-slogan', {
      business_name: businessName,
      business_type: businessType,
      target_users: targetUsers,
      city
    })

    setResult(res.data.result)
  }

  return (
    <div style={{padding:40,fontFamily:'sans-serif'}}>
      <h1>AI 本地商家获客 Agent</h1>

      <input placeholder="商家名称" onChange={(e)=>setBusinessName(e.target.value)} />
      <br /><br />

      <input placeholder="行业" onChange={(e)=>setBusinessType(e.target.value)} />
      <br /><br />

      <input placeholder="目标用户" onChange={(e)=>setTargetUsers(e.target.value)} />
      <br /><br />

      <input placeholder="城市" onChange={(e)=>setCity(e.target.value)} />
      <br /><br />

      <button onClick={generate}>
        生成营销文案
      </button>

      <pre style={{marginTop:30,whiteSpace:'pre-wrap'}}>
        {result}
      </pre>
    </div>
  )
}